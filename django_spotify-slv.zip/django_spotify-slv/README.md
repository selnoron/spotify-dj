# django_mvc

Django MVC

# How to deploy ?

## Install requirements

pip install -r tools/requirements/base.txt

## Apply migrations

python3 manage.py migrate

## Create superuser

python3 manage.py createsuperuser

## Runserver

python3 manage.py runserver
